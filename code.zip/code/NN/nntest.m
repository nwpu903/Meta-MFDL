function [er, bad] = nntest(nn, x, y, opt)
    labels = nnpredict(nn, x, opt);
    [~, expected] = max(y,[],2);
    bad = find(labels ~= expected);    
    er = numel(bad) / size(x, 1);
end
