function [er,labels,prob] = nnstacktest(nn, x, y, opt, k)
    [labels,prob] = nnstackpredict(nn, x, opt, k);
    [~, expected] = max(y,[],2);
    bad=sum(expected~=labels);
    er = bad / size(x, 1);
end

