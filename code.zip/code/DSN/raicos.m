function y=raicos(t)
y=cos(pi*t)