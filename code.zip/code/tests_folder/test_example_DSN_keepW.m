%function [er] = test_example_DSN_keepW(iterations)
% load mnist_uint8;
%load data.mat;
% train_x = [train_700_zheng(1:500,:);train_700_fu(1:500,:)];
% test_x = [train_700_zheng(501:1000,:);train_700_fu(501:1000,:)];
% train_y=zeros(1000,2);
% train_y(1:500,1)=1;train_y(501:1000,2)=1;
% test_y=zeros(1000,2);
% test_y(1:500,1)=1;test_y(501:1000,2)=1;
 train_x = double(train_x); 
 test_x  = double(test_x); 
 train_y = double(train_y); 
 test_y  = double(test_y);  
 
iterations=58;   
%%  ex2 train a 100-100 hidden unit dsn and use its weights to initialize a NN
rand('state',0);
%train dsn
dsn.sizes = [107];              
opts.numepochs = 40;             
opts.batchsize = 20;         
opts.momentum  =   0.05;            
opts.alpha     =   0.01;        
opts.stack     =   0;            
dsn = dsnsetup(dsn, train_x, opts);
dsn = dsntrain(dsn, train_x, opts);
%unfold dsn to nn
nn = dsnunfoldtonn(dsn, 2);     
nn.activation_function = 'sigm';
%train nn
opts.numepochs =  40;     
opts.batchsize = 20;  
nn = finetuning(nn, train_x, train_y, opts);
%figure; visualize(dbn.rbm{1}.W');   %  Visualize the RBM weights
for i = 1 : iterations
    nn = piledsns( nn );
    opts.stack     =   i;
    %update new training set
    train_x = [nn.label train_x];
    
    nn = finetuning(nn, train_x, train_y, opts);
end

%fix length before testing
%len = size(nn.W{1}, 2);
%nn.W{1} = nn.W{1}(:, 10*opts.stack+1:len);
EE=[];LL=cell(iterations+1,1);PP=cell(iterations+1,1);
for i = 1 : iterations + 1
    [er,labels,prob] = nnstacktest(nn, test_x, test_y, opts, i); 
    EE=[EE;er];     
    LL{i}=labels;  
    PP{i}=prob;    
end

%assert(er < 0.08, 'Too big error');
