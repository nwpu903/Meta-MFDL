require(ORFT)

# generate poaitive and negative ORFs��transfer  ��zhengfuFF()��
################################
dat.dir<-'orf_information'
anno.dir<-'annotation_information'

list.files(dat.dir,full=T)->p1
list.files(anno.dir,full=T)->p2
gsub("(.*)_\\d+.*","\\1",basename(p1))->jun
sapply(jun,function(xxx) grep(xxx,p2,value=T))->p2
data.frame(datf=p1,annof=p2,jun=jun)->todo
#p2[sapply(p2,length)!=1]
head(todo)

####
if(!file.exists('orf_zhengfu')) dir.create('orf_zhengfu')
setwd('orf_zhengfu')
apply(todo,1,function(xxx)
{
  cat(xxx[1],"==========\n")
  try(zhengfuFF(paste("../",xxx[1],sep=''), paste("../",xxx[2],sep=''), xxx[3]))-> resu
})->wu

# generate Zcurve feature of positive ORFs;transfer "tezhengwrap()" 
setwd("F:/R package")
list.files('orf_zhengfu',pattern='\\.zorf$',full=T)->todo
#todo
lapply(todo,function(xxx)
{
  cat(xxx,"=====\n")
  try(tezhengwrap(xxx))
}
)->wu


# generate Zcurve feature of negative ORFs;transfer "tezhengwrap()"
list.files('orf_zhengfu',pattern='\\.forf$',full=T)->todo
#todo
lapply(todo,function(xxx)
{
  cat(xxx,"=====\n")
  try(tezhengwrap(xxx))
}
)->wu

# generate positive features(including mono-codon usage and mono-amoniacid usage).transfer "MY.func()".

list.files('orf_zhengfu',pattern='zorf$',full=T)->what
what
lapply(what, function(xxx) MY.func(xxx))

# generate negative features(including mono-codon usage and mono-amoniacid usage).transfer "MY.func()".

list.files('orf_zhengfu',pattern='forf$',full=T)->what
what
lapply(what, function(xxx) MY.func(xxx))

# generate ORF length coverage of positive ORFs. Transfer "lencoverage()".
list.files('orf_zhengfu',pattern='\\.zorf$',full=T)->ges
lencoverage(ges)

# generate ORF length coverage of negative ORFs. Transfer "lencoverage()".
list.files('orf_zhengfu',pattern='\\.forf$',full=T)->ges
lencoverage(ges)



